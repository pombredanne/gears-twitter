# Fuel UX Gear API

The Fuel UX Gear API utilizes [Postmonger.js](http://kevinparkerson.github.com/postmonger/) to enable cross-domain Gear/Editor communication via a simple event system.

Note: this project is still heavily under construction and is not yet recommended for external use.

## Documentation and Examples

Coming Soon.

## Copyright and license

Copyright (c) 2012 ExactTarget

Licensed under the MIT License (the "License");
you may not use this work except in compliance with the License.
You may obtain a copy of the License in the COPYING file.

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.